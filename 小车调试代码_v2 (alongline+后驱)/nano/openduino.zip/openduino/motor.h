#ifndef _MOTOR_H
#define _MOTOR_H

#include "Servo.h"
#include "encoder&LED.h"

#define pinL 7  // the number of pin
#define pinR 8
#define left 0
#define right 1

void motorInit();
void alongLine(int setDistance, int setSpeeed, int mode = 0, float setAngle = -1, float setBias = 0);
void alongCurve(int setDistance, int setSpeeed, float setBias, int mode = 0);
void turn(float angletoturn, int mode, bool smoothTurn = false);
void standBy();
void walk(float left_speed, float right_speed);
//void pureTurn(float aimAngle, int mode = 0);

#endif // !_MOTOR_H
